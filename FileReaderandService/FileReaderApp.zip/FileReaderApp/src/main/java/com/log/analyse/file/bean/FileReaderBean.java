package com.log.analyse.file.bean;

import java.time.LocalDateTime;

public class FileReaderBean {

	private long count;
	private LocalDateTime dateTime;
	private String url;
	public long getCount() {
		return count;
	}
	public void setCount(long count) {
		this.count = count;
	}
	public LocalDateTime getDateTime() {
		return dateTime;
	}
	public void setDateTime(LocalDateTime dateTime) {
		this.dateTime = dateTime;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	
	
}
