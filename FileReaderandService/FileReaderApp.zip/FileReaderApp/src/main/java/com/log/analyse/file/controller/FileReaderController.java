package com.log.analyse.file.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.log.analyse.file.bean.FileReaderBean;
import com.log.analyse.file.service.FileReaderService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping(value="/api")
@Api(value="File Reader API")
public class FileReaderController {
	
	@Autowired
	FileReaderService fileReaderService;

	@PostMapping(value="/saveanalytics" ,consumes=MediaType.APPLICATION_JSON_VALUE)
	public void postMethod(@RequestBody FileReaderBean fileReaderBean) {
		fileReaderService.SaveRecords(fileReaderBean);

	}

}
