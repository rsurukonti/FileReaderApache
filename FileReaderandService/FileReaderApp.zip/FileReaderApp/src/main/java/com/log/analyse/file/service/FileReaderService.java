package com.log.analyse.file.service;

import org.springframework.stereotype.Service;

import com.log.analyse.file.bean.FileReaderBean;

@Service
public interface FileReaderService {

	public void SaveRecords(FileReaderBean fileReaderBean);
}

