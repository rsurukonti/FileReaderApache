package com.log.analyse.file.repository;

import org.springframework.data.repository.CrudRepository;

import com.log.analyse.file.entity.FileReaderEntity;

public interface FileReaderRepository  extends CrudRepository<FileReaderEntity, Long>  {

}
