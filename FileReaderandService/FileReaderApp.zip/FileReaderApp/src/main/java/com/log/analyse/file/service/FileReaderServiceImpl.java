package com.log.analyse.file.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.log.analyse.file.bean.FileReaderBean;
import com.log.analyse.file.entity.FileReaderEntity;
import com.log.analyse.file.repository.FileReaderRepository;

@Service
public class FileReaderServiceImpl implements FileReaderService {
	
	@Autowired
	private FileReaderRepository filereaderRep;
	
	@Autowired
	private ModelMapper modelMapper;

	@Override
	public void SaveRecords(FileReaderBean fileReaderBean) {
		FileReaderEntity employeeEntity =convertToEntity(fileReaderBean);
		filereaderRep.save(employeeEntity);
	}
	public FileReaderEntity convertToEntity(FileReaderBean bean) {
		return modelMapper.map(bean, FileReaderEntity.class);


	}
}
